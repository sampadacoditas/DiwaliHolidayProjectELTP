
export const database=[
        {date:"23 dec 2022",status:"all"},
        {date:"12 nov 2022",status:"all"},
        {date:"22 Nov 2023",status:"all"}
    ]
