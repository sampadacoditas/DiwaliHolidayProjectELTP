export interface ICard
{
    cardHeading:string,
    buttonText1:string,
    buttonText2:string,
    Date?:any,
    dispatch?:any,
    state?:any,
    element?:any
}